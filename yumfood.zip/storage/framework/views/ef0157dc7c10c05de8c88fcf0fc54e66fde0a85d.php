<!DOCTYPE html>
<html>
<head>
    <title>CRUD Order</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(('../css/bootstrap.min.css')); ?>">
</head>
<body>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4>Order Edit</h4>
            </div>
            <div class="panel-body">
                <form action="<?php echo e(url('update', $data->id)); ?>" method="post">
                    <!-- <input type="hidden" name="id" id="id" value="<?php echo e($data->id); ?>"> -->
                    <div class="form-group">
                        <div class="col-sm-6">
                            <label for="nama">Restaurant Name</label>
                            <input type="text" name="nama" id="nama" value="<?php echo e($data->restaurant_name); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-3">
                            <label for="vendor">Vendor</label>
                            <select name="vendor" id="vendor" class="form-control" required="require">
                                <option value="<?php echo e($data->vendor_id); ?>"><?php echo e($data->vendor->name); ?></option>
                                <?php $__currentLoopData = $itemlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>  
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-3">
                            <label for="vendor">Tag</label>
                            <select name="tag" id="tag" class="form-control" required="require">
                                <option value="<?php echo e($data->tag_id); ?>"><?php echo e($data->tag->name); ?></option>
                                <?php $__currentLoopData = $itemlistx; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($itemx->id); ?>"><?php echo e($itemx->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-3">
                            <label for="qty">Quantity</label>
                            <input type="number" name="qty" id="qty" value="<?php echo e($data->qty); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-3">
                            <label for="price">Price</label>
                            <input type="number" name="price" id="price" value="<?php echo e($data->price); ?>" class="form-control"  onchange="hasil()">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-3">
                            <label for="amount">Amount</label>
                            <input type="hidden" name="amount" id="amount" value="<?php echo e($data->amount); ?>" class="form-control">
                            <input type="number" name="amountx" id="amountx" value="<?php echo e($data->amount); ?>" class="form-control"  disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="send" id="send" value="Simpan" class="btn btn-success"><?php echo csrf_field(); ?>                       
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

<script>
function hasil(){
    var qty = document.getElementById('qty').value
    var price = document.getElementById('price').value

    var hasil = parseInt(qty) * parseInt(price)
    document.getElementById('amount').value = hasil
    document.getElementById('amountx').value = hasil

}

</script><?php /**PATH C:\xampp\htdocs\yumfood\resources\views/edit.blade.php ENDPATH**/ ?>