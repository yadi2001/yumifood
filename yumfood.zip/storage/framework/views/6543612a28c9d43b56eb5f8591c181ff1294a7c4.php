<!DOCTYPE html>
<html>
<head>
    <title>CRUD Order</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(('css/bootstrap.min.css')); ?>">
</head>
<body>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4>CRUD Order</h4>
            </div>
            <div class="panel-body">
                <form action="<?php echo e(url('create')); ?>" method="get">
                    <div class="form-group">
                        <input type="submit" name="new" id="new" value="New Order" class="btn btn-success">
                    </div>
                </form>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Restaurant Name</th>
                            <th>Vendor</th>
                            <th>Tag</th>
                            <th>Qty</th>
                            <th>Price(Rp)</th>
                            <th>Amount(Rp)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->restaurant_name); ?></td>
                            <td><?php echo e($d->vendor->name); ?></td>
                            <td><?php echo e($d->tag->name); ?></td>
                            <td><?php echo e($d->qty); ?></td>
                            <td><?php echo e(number_format($d->price,2)); ?></td>
                            <td><?php echo e(number_format($d->amount,2)); ?></td>
                            <td>
                                <a href="<?php echo e(url('read',array($d->id))); ?>">Read</a>
                                <a href="<?php echo e(url('delete',array($d->id))); ?>">Delete</a>
                                <a href="<?php echo e(url('edit',array($d->id))); ?>">Edit</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody> 
 
                </table>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\yumfood\resources\views/order.blade.php ENDPATH**/ ?>